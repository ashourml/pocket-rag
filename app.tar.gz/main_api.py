from flask import Flask, Response,redirect,url_for,render_template,request , make_response
from llama_index.llms.ollama import Ollama 
from llama_index.core import Settings 
from llama_index.embeddings.ollama import OllamaEmbedding
from lmparse import RAG


Settings.llm = Ollama(
    model='wizardlm2:latest',
    temperature=0,
    context_window=1024,
    request_timeout=480.0 ,
    additional_kwargs={'num_predict' : 100} 
)

Settings.embed_model = OllamaEmbedding(
    model_name='nomic-embed-text:v1.5',
    embed_batch_size=10,
)

app=Flask(__name__)

model = Ollama(model='llama3.1' , temperature=1 )

@app.route('/ai',methods=['POST'])
def ai_response():

    json_data = request.json
    data = json_data.get('query')
    response = model.invoke(data)
    
    return response , 200

@app.route('/pdfanalyzer', methods=['POST'])
def pdf_analyzer():
    json_data = request.json
    file_name = json_data.get('file_name')
    file_path = json_data.get('file_path')
    
    rag = RAG(filename= file_name  ,file_path=file_path)
    
    response = {'status' : 'Analyse success ...'}
    
    return response , 200


    
@app.route('/generate', methods=['POST'])
def generate():
    json_data = request.json
    file_name = json_data.get('file_name')
    file_path = json_data.get('file_path')
    prompt = json_data.get('prompt')
    
    rag = RAG(filename=file_name, file_path=file_path)
    
    def stream():
        respo = rag.Act(prompt=prompt )
        for chunk in respo.response_gen:
            
            yield chunk
            
    return Response(stream(), content_type='text/plain') 

if __name__ == '__main__':
    #DEBUG is SET to TRUE. CHANGE FOR PROD
    app.run(host='0.0.0.0',port=8080,debug=True)