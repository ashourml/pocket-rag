from flet import *


class testpa(View):

    def __init__(self , page: Page):
        super().__init__(route= '/test')

    
        self.controls = [
            Text(
                'this is test page'
            )
        ]