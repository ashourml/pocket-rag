from flet import *


# class RecentProjects(ListTile):
#     def __init__(self , file_name : str , file_path , function ):
#         super().__init__()

#         self.title = Text(value=file_name , size=12)
#         self.data = {
#             'file_name' : file_name,
#             'file_path' : file_path
#         }
#         self.expand = True
#         self.selected_color = colors.AMBER
#         self.shape = RoundedRectangleBorder(radius=5)
#         self.hover_color = colors.YELLOW

#         self.on_click = function


class RecentProjects(Container):
    def __init__(self, file_name: str, file_path, function):
        super().__init__()

        self.on_click = self.click
        self.border_radius = 10
        self.bgcolor = colors.TRANSPARENT
        self.content = Text(
                value=file_name,
                size=12,
                data={
                    'file_name': file_name,
                    'file_path': file_path
                }
            )
        self.on_click = function
        self.on_hover = self.hover
        self.margin = 2
        self.padding = padding.only(left=3)

    def hover(self, e):
        e.control.bgcolor = colors.WHITE38 if e.control.bgcolor == colors.TRANSPARENT else colors.TRANSPARENT
        e.control.update()

    def click(self, e):
        e.control.bgcolor = colors.WHITE38 if e.control.bgcolor == colors.TRANSPARENT else colors.TRANSPARENT
        e.control.update()

