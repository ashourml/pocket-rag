
import json
import os

# The `history` class is designed to store and update chat messages between a user and an AI, saving
# the conversation history to a JSON file.
class history():
    def __init__(self) -> None:
        super().__init__()
        
        self.history = {}
        self.user = ''
        self.ai = ''
        self.msg = {}
        self.chat = []
        
    def add_user_msg(self , key , user ):
        self.user = user
        
    def add_ai_msg(self , key , ai):
        
        self.ai = ai
    
    def StoreChat(self , key):
        self.chat.append(
            {
                'user' :self.user, 
                'ai' : self.ai
            }
        )
        
        self.history[key] = self.chat
        
        if os.path.exists('history'):
            print('----path exist ----')
            with open(f'history/{key}_chat_history.json' , 'w') as jsonfile :
                json.dump(self.history , jsonfile)
        
        elif not os.path.exists('history'):
            print('----new created----')
            os.mkdir('history')
            with open(f'history/{key}_chat_history.json' , 'w') as jsonfile :
                json.dump(self.history , jsonfile)
             
