from flet import *




class Snack(SnackBar):
    def __init__(self , message : str):
        super().__init__(content=Text(value=message))
    
        
        self.behavior = SnackBarBehavior.FLOATING
        self.bgcolor = colors.WHITE70
        
        