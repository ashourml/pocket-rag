from flet import *
from UI.main_page.strings import *

class DragBar(WindowDragArea):
    def __init__(self , page):
        super().__init__(content=Container)
        
        self.page = page
        self.background_color = colors.BLACK54
        self.shadow = shadow
        
        
        self.chat_icon = IconButton(
            icon=icons.CHAT_BUBBLE_ROUNDED,
            scale=0.8,
            bgcolor=colors.TRANSPARENT,
            icon_color=colors.WHITE
        )

        self.search_icon = IconButton(
            icon=icons.SEARCH_ROUNDED,
            scale=0.8,
            bgcolor=colors.TRANSPARENT,
            icon_color=colors.WHITE
        )

        self.close_icon = IconButton(
            icon=icons.CLOSE_ROUNDED,
            scale=0.8,
            bgcolor=colors.TRANSPARENT,
            icon_color=colors.WHITE,
            on_click=lambda x : self.page.window.close()
        )
        
        
        
        
        self.content = Container(
            height=40,
            border_radius=10,
            bgcolor=self.background_color,
            shadow=self.shadow,
            content=Row(
                alignment=MainAxisAlignment.SPACE_BETWEEN,
                controls=[
                    Row(
                        alignment=MainAxisAlignment.START,
                        controls=[
                            Container(
                                # bgcolor=foreground_color,
                                # border_radius=30,
                                content=Image(
                                    src=r'assets\images\logo-L.png',
                                    scale=0.7,
                                    
                                ),
                                on_click=lambda x: print('logo clicked')

                            ),
                        ],

                    ),
                    Row(
                        alignment=MainAxisAlignment.END,
                        controls=[
                            VerticalDivider(
                                thickness=0.3,
                                color=colors.WHITE
                            ),

                            self.search_icon,
                            self.chat_icon,
                            self.close_icon
                        ],

                    )
                ]
            )
        )


