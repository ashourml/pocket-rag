from flet import *



class Saver_Loader():
    
    def __init__(self , page):
        super().__init__()
        self.page = page
        
        
    def Save(self, key : str , data ) -> None : 
        
        self.page.client_storage.set(key  , data)
    
    
    def Load(self, key : str , data ) -> None : 
    
        self.page.client_storage.get(key  , data)
    
    
    