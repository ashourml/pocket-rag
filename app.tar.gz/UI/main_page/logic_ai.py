from langchain_experimental.llms.ollama_functions import OllamaFunctions, convert_to_ollama_tool
from langchain.chains import LLMChain
from langchain_core.pydantic_v1 import BaseModel, Field, Json
from langchain_core.prompts import PromptTemplate
import json
with open('df_des.json', 'r') as json_txt:
    dataframe_details = json.loads(json_txt.read())

class AutonomousMachineLearningEngineer(BaseModel):

    """
    Serve as an autonomous AI machine learning engineer, generating comprehensive Python code to build machine learning models
    based on user instructions. The output should be formatted in markdown and include the following fields: 
    full_markdown_machine_learning_python_code, markdown_report, interactive_code_update_instructions, and freeform_conversation.
    The generated code should be executable with the exec() Python method. Facilitate the use of various machine learning algorithms
    and techniques through ongoing user interaction.
    """

    full_markdown_machine_learning_python_code: str = Field(
        
        description='Comprehensive machine learning Python code generated based on user instructions, formatted as a markdown code snippet.',
        required = True
    )

    markdown_report: str = Field(
        required  =True,
        description='Detailed, step-by-step explanations of the methods, algorithms, and techniques used in the generated code, formatted in markdown.'
    )

    interactive_code_update_instructions: str = Field(
        required  =True,
        description='Instructions for interactively updating the existing code based on further user input. Support ongoing conversational updates for iterative model development.'
    )

    freeform_conversation: str = Field(
        required  =True,
        description='Freeform conversation with the AI. When the user requests a code update, the AI should update the code accordingly.'
    )


prompt_template_str = """
    Based on the following dataset description, generate a {task} machine learning model:

    Dataset Description:
    {dataset_description}

    Please include all necessary imports, data preprocessing, model training, and evaluation code.
    """
def generate_langchain_prompt(dataset_description: str, task: str) -> str:
    
    return prompt_template_str.format(dataset_description=dataset_description, task=task)
    

def generate_code_with_langchain(dataset_description: str, task: str) -> str:


    model = OllamaFunctions(
        model='llama3',
        temperature=0,
        format='json',
        num_predict=-1,
        top_k=10,
        top_p=0.5,
        row=True,
        keep_alive='10m',
    )
    code_tool = convert_to_ollama_tool(AutonomousMachineLearningEngineer)
    model_tool = model.bind_tools([code_tool])

    # Create the prompt
    prompt = generate_langchain_prompt(
        dataset_description=dataset_description ,
        task=task
        )
    prompt_template = PromptTemplate(template=prompt_template_str, input_variables=["task", "dataset_description"])
    # Initialize the LLMChain with the prompt
    chain = LLMChain(
        llm=model_tool,
        prompt=PromptTemplate(prompt_template)
        )

    # Generate the code
    generated_code = chain.run()

    return generated_code


respo = generate_code_with_langchain(dataset_description=dataframe_details , task='regression')
print(respo)