from flet import *
from main_page.strings import *
from main_page.main_ui_controllers import *
from ML_logic.data_importer import DataImporter
from ML_logic.data_analysis import DataDescriber



# describer = DataDescriber(path=r"data\Housing.csv")
# column_num = describer.data_columns_num
# columns = describer.data_columns

# print(column_num)
