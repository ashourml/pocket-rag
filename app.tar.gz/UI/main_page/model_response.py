from flet import *


class ModelResponseContainer(Column):
    def __init__(self):
        super().__init__()

        self.controls = [
            Row(
                controls=[
                    CircleAvatar(
                        content=Image(
                            src=r"assets\images\logo_sy.png",
                        ),
                        scale=0.5,
                        bgcolor=colors.TRANSPARENT,
                    ),
                    Container(
                        expand=True,
                        content=Container(
                            border_radius=10,
                            alignment=alignment.top_left,
                            content=Column(
                                controls=[
                                    Markdown(
                                        selectable=True,
                                        value='',
                                        extension_set="gitHubWeb",
                                        code_theme="atom-one-dark",

                                        on_tap_link=lambda e: self.page.launch_url(
                                            e.data),
                                    ),
                                    Row(
                                        alignment=CrossAxisAlignment.END,
                                        controls=[
                                            IconButton(
                                                icon=icons.COPY_ROUNDED,
                                                icon_size = 15,
                                                icon_color=colors.WHITE
                                            )
                                        ]
                                    )
                                ]
                            ),
                            expand=True
                        ),
                        padding=padding.all(5),

                    ),
                ],
                spacing=0
            )
        ]
