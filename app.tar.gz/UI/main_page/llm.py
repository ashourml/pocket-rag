from langchain_community.llms import Ollama , openai
from langchain_openai import ChatOpenAI
from langchain_community.embeddings import OllamaEmbeddings
from langchain_community.document_loaders import PyPDFLoader

from langchain_experimental.agents import create_pandas_dataframe_agent
from langchain_experimental.tools import PythonAstREPLTool
from langchain_community.utilities import SQLDatabase
from langchain_community.agent_toolkits import create_sql_agent
from sqlalchemy import create_engine
import pandas as pd 
from langchain_community.vectorstores import faiss
from dotenv import load_dotenv

load_dotenv('.env')
llm = Ollama(model = 'llama2')
loader = PyPDFLoader("2.MVVMDemonstrationUsingC.pdf")
pages = loader.load_and_split()
faiss_index = faiss.from_documents(pages, OllamaEmbeddings(model='tinyllama'))
docs = faiss_index.similarity_search("Model View Model Design", k=2)
for doc in docs:
    print(str(doc.metadata["page"]) + ":", doc.page_content[:300])



