from pydantic import BaseModel, Field

class promptgenerator(BaseModel):
    """
    Serve as an autonomous AI machine learning engineer, generating comprehensive Python code to build machine learning models
    based on user instructions and detailed dataset information. The output should be formatted in markdown and include the 
    following fields: full_markdown_machine_learning_python_code, markdown_report, interactive_code_update_instructions, and 
    freeform_conversation. The generated code should be executable with the exec() Python method. Facilitate the use of various 
    machine learning algorithms and techniques through ongoing user interaction.
    """

    dataset_info: str = Field(
        default_factory=str,
        description='Detailed information about the dataset, including column details, descriptive statistics, correlation matrix, and data integrity.'
    )

    full_markdown_machine_learning_python_code: str = Field(
        description='Comprehensive machine learning Python code generated based on user instructions, formatted as a markdown code snippet.',
        required=True
    )

    markdown_report: str = Field(
        required=True,
        description='Detailed, step-by-step explanations of the methods, algorithms, and techniques used in the generated code, formatted in markdown.'
    )

    interactive_code_update_instructions: str = Field(
        required=True,
        description='Instructions for interactively updating the existing code based on further user input. Support ongoing conversational updates for iterative model development.'
    )

    freeform_conversation: str = Field(
        required=True,
        description='Freeform conversation with the AI. When the user requests a code update, the AI should update the code accordingly.'
    )

    @staticmethod
    def generate_prompt(user_input: str, dataset_info: str) -> str:
        """
        Generate a prompt that includes detailed dataset information and the user's input about the machine learning model they want to create.
        """
        prompt = f"""
        Based on this information:
        {dataset_info}
        Please code for me {user_input}.
        """
        return prompt

# Example usage:

user_input = "a linear regression model to predict the house prices based on the dataset."



