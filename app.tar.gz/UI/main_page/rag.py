from langchain_community.document_loaders import WebBaseLoader
from langchain_community.vectorstores import Chroma
from langchain_community import embeddings
from langchain_community.chat_models import ChatOllama
from langchain_core.runnables import RunnablePassthrough
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain.chains.combine_documents import create_stuff_documents_chain
from langchain_text_splitters import RecursiveCharacterTextSplitter
from googlesearch import search
from langchain_core.messages import HumanMessage


llm = ChatOllama(model="llama3", keep_alive=True)


def searching(model, keyword: str):
    # Step 1: Perform a search using googlesearch-python
    query = keyword
    num_results = 3  # Number of search results to retrieve

    search_results = search(query, num_results=num_results)

    # Step 2: Fetch the content from the URLs

    docs = WebBaseLoader([url for url in search_results]).load()   # get docs from urls
    
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=1000, chunk_overlap=100)
    doc_split = text_splitter.split_documents([docs[0]])

    # Step 3: convert documents to embeddings and store them
    vectorstore = Chroma.from_documents(
        documents=doc_split,
        collection_name='search_rag',
        embedding=embeddings.OllamaEmbeddings(model='nomic-embed-text:latest')
    )

    retriever = vectorstore.as_retriever(k=3)

    # documents = retriever.invoke('what is covid 25 ?')

    SYSTEM_TEMPLATE = """
    Answer the user's questions based on the below context. 
    If the context doesn't contain any relevant information to the question, don't make something up and just say "I don't know":

    <context>
    {context}
    </context>
    """

    question_answering_prompt = ChatPromptTemplate.from_messages(
        [
            (
                "system",
                SYSTEM_TEMPLATE,
            ),
            MessagesPlaceholder(variable_name="messages"),
        ]
    )
    document_chain = create_stuff_documents_chain(model, question_answering_prompt)
    
    
    print(document_chain.invoke(
        {
            'context': retriever,
             "messages": [
            HumanMessage(content=" describe covid 25 in one line ")
        ],
        }
    ))
    
    

searching(model=llm, keyword='covid 25')
