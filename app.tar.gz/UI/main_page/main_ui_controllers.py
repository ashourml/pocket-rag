from flet import *
from main_page.strings import *
from main_page.main_logic import *

import pandas as pd


def headers(df: pd.DataFrame) -> list:
    return [DataColumn(Text(header)) for header in df.columns]


def rows(df: pd.DataFrame) -> list:
    rows = []
    for index, row in df.iterrows():
        rows.append(
            DataRow(cells=[DataCell(Text(row[header])) for header in df.columns]))
    return rows


data = pd.read_csv(r'data\Housing.csv')
df = pd.DataFrame(data)


def get_dim():
    global w
    global h
    for m in get_monitors():
        if m.is_primary:
            w = m.width
            h = m.height


# -------------get_dim-----------
get_dim()


shadow = BoxShadow(
    spread_radius=4,
    blur_radius=5,
    color=colors.BLACK12,
)

component_shadow = BoxShadow(
    spread_radius=2,
    blur_radius=3,
    color=colors.with_opacity(0.05, color=content_color),
)
chat_icon = IconButton(
    icon=icons.CHAT_BUBBLE_ROUNDED,
    scale=0.8,
    bgcolor=colors.TRANSPARENT,
    icon_color=colors.WHITE
)


search_icon = IconButton(
    icon=icons.SEARCH_ROUNDED,
    scale=0.8,
    bgcolor=colors.TRANSPARENT,
    icon_color=colors.WHITE
)
# col={"sm": 0.33, "md": 0.33, "xl": 0.33}


close_icon = IconButton(
    icon=icons.CLOSE_ROUNDED,
    scale=0.8,
    bgcolor=colors.TRANSPARENT,
    icon_color=colors.WHITE
)
# col={"sm": 0.33, "md": 0.33, "xl": 0.33},

logo = Container(
    # bgcolor=foreground_color,
    # border_radius=30,
    content=Image(
        src=r'assets\icons\Asset-1.png',
        scale=0.4,


    ),
    on_click=lambda x: print('logo clicked')

)
drag_bar = WindowDragArea(
    content=Container(
        height=40,
        border_radius=20,
        bgcolor=foreground_color,
        shadow=shadow,
        content=Row(
            alignment=MainAxisAlignment.SPACE_BETWEEN,
            controls=[
                Row(
                    alignment=MainAxisAlignment.START,
                    controls=[
                        logo,
                    ],
                ),
                Row(
                    alignment=MainAxisAlignment.END,
                    controls=[
                        VerticalDivider(
                            thickness=0.3),

                        search_icon,
                        chat_icon,
                        close_icon
                    ],

                )
            ]
        )
    ),
    maximizable=False,

)


main_chat_listview = ListView(

    auto_scroll=True,
    padding=padding.all(10),
    spacing=5,
    controls=[
    ],


)
main_chat_container = Container(
    bgcolor=colors.BLACK54,
    border_radius=15,
    top=10,
    left=10,
    right=10,
    bottom=70,
    shadow=shadow,
    content=main_chat_listview

)
main_chat_user_input = TextField(

    label='Enter your prompt ...',
    bgcolor=colors.BLACK54,
    border_radius=15,
    hint_text='enter your prompt EX: code login page with modern style .',
    hint_style=TextStyle(
        weight=FontWeight.W_100
    ),
    height=40,
    width=510,
    content_padding=padding.all(10),
    on_blur=lambda x: print('fou'),
    border=BorderSide(width=None)
)
main_chat_user_input_submit = IconButton(
    icon=icons.SEND_ROUNDED,
    icon_color=colors.BLACK54,
    scale=1,
    tooltip='send prompt',
)
main_container_input_row = Row(
    alignment=alignment.center,
    controls=[
        main_chat_user_input,
        main_chat_user_input_submit
    ],
    bottom=10,
    top=560,
    left=10,
    right=10
)

bot_column = Column(
    alignment=CrossAxisAlignment.START,
    controls=[
        main_chat_container,
        main_container_input_row,
    ], top=10,
    right=10,
    left=10,
    bottom=10,
)


side_bar = Container(
    width=150,
    height=825,
    border_radius=20,
    bgcolor=foreground_color,
    shadow=shadow,
    content=Stack(
        controls=[

        ]
    ),

)
expand_icon = IconButton(
    icon=icons.EXPAND_LESS,
    scale=0.5,
    icon_color=colors.WHITE,
    rotate=45,

)


details_con = Container(
    width=300,
    height=200,
    shadow=shadow,
    bgcolor=foreground_color,
    border_radius=10,
    content=Column(
        controls=[
            Row(
                alignment=MainAxisAlignment.CENTER,
                spacing=50,
                controls=[
                    Text(
                        value='Dataset details',
                        style=text_style_header
                    ),
                ]
            ),
            Divider(thickness=0.2),
        ],
        alignment=alignment.center
    ),
    padding=padding.all(5)


)

statistics_con = Container(
    shadow=shadow,
    width=300,
    height=200,
    bgcolor=foreground_color,
    border_radius=10,
    content=Column(
        controls=[
            Row(
                alignment=MainAxisAlignment.CENTER,
                spacing=50,
                controls=[
                    Text(
                        value='Dataset Overview Statistics',
                        style=text_style_header
                    ),
                ]
            ),
            Divider(thickness=0.2),
        ],
        alignment=alignment.center
    ),
    padding=padding.all(5)
)

pie_con = Container(
    shadow=shadow,
    height=200,
    bgcolor=foreground_color,
    border_radius=10,
    content=Column(
        controls=[
            Row(
                alignment=MainAxisAlignment.CENTER,
                spacing=50,
                controls=[
                    Text(
                        value='Pie chart',
                        style=text_style_header
                    ),
                ]
            ),

        ],
        alignment=alignment.center
    ),
    expand=2

)

unique_con = Container(
    shadow=shadow,
    width=300,
    height=615,
    bgcolor=foreground_color,
    border_radius=10,
    content=Column(
        controls=[
            Row(
                alignment=MainAxisAlignment.CENTER,
                spacing=50,
                controls=[
                    Text(
                        value='Unique data',
                        style=text_style_header
                    ),
                ]
            ),
            Divider(thickness=0.2),

        ],
    ),
    padding=padding.all(5)

)

placeholder_con = Container(
    bgcolor=foreground_color,
    shadow=shadow,
    width=145,
    height=100,
    border_radius=10
)
placeholder_con_double = Container(
    bgcolor=foreground_color,
    shadow=shadow,
    width=300,
    height=505,
    border_radius=10
)


ploting_con_top = Container(
    bgcolor=foreground_color,
    shadow=shadow,
    width=685,
    height=407,
    border_radius=20
)

def plot_animate(e):
    ploting_con_down.width = 900 if ploting_con_down.width == 685 else 685
    ploting_con_down.update()
    
    
ploting_con_down = Container(
    bgcolor=foreground_color,
    shadow=shadow,
    width=685,
    height=407,
    border_radius=20,
    content=Column(
        expand=True,
        scroll=True,
        on_scroll_interval=10,
        controls=[
            # DataTable(
            #     columns=headers(df=df),
            #     rows=rows(df=df),
            #     divider_thickness=0.2,
            #     data_row_color={"hovered": "0x30FF0000"},
            #     vertical_lines=border.BorderSide(0.5, colors.BLACK12),
            #     disabled=False,
                
            # ),
        ]
    ),
    animate=animation.Animation(1000,AnimationCurve.BOUNCE_OUT),
    on_hover=plot_animate

)


main_container = Column(
    alignment=MainAxisAlignment.CENTER,
    controls=[
        drag_bar,
        Row(
            controls=[
                side_bar,
                Column(
                    controls=[
                        Row(
                            controls=[
                                details_con,
                                statistics_con,
                            ]
                        ),
                        Row(
                            controls=[
                                unique_con,
                                Column(
                                    controls=[
                                        Row(
                                            controls=[
                                                placeholder_con,
                                                placeholder_con,

                                            ],
                                        ),
                                        placeholder_con_double
                                    ]
                                )
                            ]
                        )

                    ]
                ),
                Column(
                    controls=[
                        ploting_con_top,
                        ploting_con_down
                    ]
                )
            ]

        )


    ],
    expand=True,

)
main_container_right = Container(
    border_radius=20,
    shadow=shadow,
    content=Column(
        controls=[
            Row(
                controls=[


                ],
                alignment=MainAxisAlignment.SPACE_BETWEEN

            ),

        ]
    ),
    padding=padding.all(5),
    expand=5
)
