from flet import *


class ModelLoadingContainer(Column):
    def __init__(self):
        super().__init__()

        self.controls = [
            Row(
                controls=[
                    CircleAvatar(
                        content=Image(
                            src=r"assets\images\logo_sy.png",
                        ),
                        scale=0.5,
                        bgcolor=colors.TRANSPARENT,
                    ),
                    Container(
                        expand=True,
                        content=Container(
                            border_radius=10,
                            alignment=alignment.top_left,
                            content=Image(
                                src=r"assets\images\loading_dots.gif",
                                scale = 0.6,
                                color = colors.WHITE
                                ),
                            expand=True
                        ),
                        padding=padding.all(5),

                    ),
                ],
                spacing=0
            )
        ]

