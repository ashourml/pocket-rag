import re
from flet import *
from typing import Any, List, Dict


light_color = '#FFFFFF'
background_color = '#4E5652'
foreground_color = '#6E7370'
secondary_color = '#909590'
content_color = '#9AB69B'
filled_color = '#5D8064'
code_container_color = '#282C34'

text_style = TextStyle(
    size=12,
    font_family='sf',
    weight= FontWeight.W_100

    # weight=FontWeight.W_100,

)
text_style_content = TextStyle(
    size=12,
    font_family="sf",
    # weight=FontWeight.W_200,

)

text_style_header = TextStyle(
    size=11,
    font_family="sfm",
    color=colors.WHITE,
    weight=FontWeight.NORMAL
)

shadow = BoxShadow(
    spread_radius=4,
    blur_radius=5,
    color=colors.BLACK12,
    
)


html = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }

        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f0f2f5;
        }

        .container {
            width: 100%;
            max-width: 400px;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            color: #555;
        }

        input[type="email"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }

        input[type="email"]:focus,
        input[type="password"]:focus {
            border-color: #007bff;
            outline: none;
        }

        .form-group.remember-me {
            display: flex;
            align-items: center;
        }

        .form-group.remember-me input[type="checkbox"] {
            margin-right: 10px;
        }

        .btn {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .btn:hover {
            background-color: #0056b3;
        }

        .forgot-password {
            text-align: right;
            margin-top: 10px;
        }

        .forgot-password a {
            color: #007bff;
            text-decoration: none;
            transition: color 0.3s;
        }

        .forgot-password a:hover {
            color: #0056b3;
        }

        .signup-link {
            text-align: center;
            margin-top: 20px;
        }

        .signup-link a {
            color: #007bff;
            text-decoration: none;
            transition: color 0.3s;
        }

        .signup-link a:hover {
            color: #0056b3;
        }
    </style>
</head>
<body>

    <div class="container">
        <h2>Sign In</h2>
        <form action="#" method="POST">
            <div class="form-group">
                <label for="email">Email Address</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="form-group remember-me">
                <input type="checkbox" id="remember" name="remember">
                <label for="remember">Remember me</label>
            </div>
            <button type="submit" class="btn">Sign In</button>
            <div class="forgot-password">
                <a href="#">Forgot Password?</a>
            </div>
        </form>
        <div class="signup-link">
            <p>Don't have an account? <a href="#">Sign up</a></p>
        </div>
    </div>

</body>
</html>

"""