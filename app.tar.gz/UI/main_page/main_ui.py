import json
import subprocess
import time
from flet import *
from UI.main_page.strings import *
from UI.controls.client_saver import Saver_Loader
from UI.controls.snack import Snack
from .model_response import ModelResponseContainer
from .loading import ModelLoadingContainer
import pandas as pd
import time
import sys
import requests
from UI.controls.exist_project import RecentProjects
from UI.controls.chat_histroy import history

sys.path.append("..")


class MainPage(Container):
    def __init__(self, page):
        super().__init__()

        self.page = page
        self.csv_path = ''
        self.light_color = light_color
        self.background_color = background_color
        self.foreground_color = foreground_color
        self.text_style = text_style
        self.text_style_header = text_style_header
        self.text_style_content = text_style_content
        self.report_steps = ''
        self.expand = True
        self.pick_files_dialog = FilePicker(on_result=self.pick_files_result)
        self.page.overlay.extend([self.pick_files_dialog])
        self.client_se = Saver_Loader(self.page)
        self.fullrespo =[]
        self.chat_history = history()
        self.ai_respo =''
        
        
        
        self.pronounce = Column(
            controls=[
                Container(
                    bgcolor=colors.TRANSPARENT,
                    border_radius=10,
                    expand=False,
                    content=Column(
                        controls=[
                            Text(
                                value='Abdelrahman Ashour',
                                text_align=TextAlign.JUSTIFY,
                                style=text_style_header,
                                scale=0.9
                            ),
                            Text(
                                value='CEO',
                                text_align=TextAlign.JUSTIFY,
                                style=text_style_content,
                                scale=0.9
                            ),
                        ],
                        spacing=0,
                        horizontal_alignment=CrossAxisAlignment.START,

                    ),
                ),

            ],
            expand=True
        )

        self.avatar = CircleAvatar(
            content=Image(
                src=r'assets\images\ashour.jpg',
                border_radius=25,
                scale=0.9
            ),
            bgcolor=colors.TRANSPARENT,
        )

        self.create_new = IconButton(
            icon=icons.CREATE,
            icon_color=colors.WHITE,
            scale=0.8,
            tooltip='New RAG',
            on_click=lambda _: self.pick_files_dialog.pick_files(
                allow_multiple=True
            )

        )

        self.side_bar_icon = IconButton(
            icon=icons.MINIMIZE_OUTLINED,
            icon_color=colors.WHITE,
            scale=0.8
        )

        self.side_bar_list = ListView(
            expand=True,
            controls=[

            ],
            divider_thickness=0.3,


        )
        self.left_side_container = Container(
            width=150,
            bgcolor=colors.BLACK54,
            border_radius=8,
            content=Column(
                controls=[
                    Container(height=5),
                    Container(
                        height=40,
                        content=Row(
                            controls=[
                                self.avatar,
                                self.pronounce
                            ],
                            alignment=MainAxisAlignment.CENTER,
                        ),
                    ),
                    Divider(
                        color=colors.WHITE60,
                        thickness=0.4
                    ),
                    Row(
                        alignment=MainAxisAlignment.SPACE_BETWEEN,
                        controls=[
                            self.side_bar_icon,
                            self.create_new,
                        ]
                    ),

                    Container(
                        content=self.side_bar_list,
                        expand=True
                    ),
                    Row(
                        alignment=MainAxisAlignment.SPACE_BETWEEN,
                        controls=[
                            IconButton(
                                icon= icons.LOGOUT,
                                scale=0.7,
                                icon_color=colors.WHITE,
                                on_click= self.signout
                                ),
                            IconButton(
                                icon=icons.SETTINGS,
                                scale=0.7,
                                icon_color=colors.WHITE,
                            )
                        ]
                    )
                ],
                horizontal_alignment=CrossAxisAlignment.CENTER,
                expand=True,
                disabled=False,
            ),
            animate=animation.Animation(
                duration=1000, curve=AnimationCurve.FAST_OUT_SLOWIN
            ),
            padding=padding.only(left=2),
            disabled=False
        )

        self.standard_screen = Container(
            content=Image(
                src=r'assets\images\logo4x.png',
                scale=0.4,
                opacity=0.3
            ),
        )
        # ----------------chat controls--------------------
        self.main_chat_listview = ListView(
            expand=True,
            # auto_scroll=True,
            padding=padding.all(10),
            spacing=5,
            controls=[

            ],
            item_extent=False,
        )

        self.bot_text = Text(
            value='',
            text_align=TextAlign.JUSTIFY,
            style=text_style,
        )

        self.main_chat_container = Container(
            bgcolor=colors.TRANSPARENT,
            border_radius=15,
            content=self.main_chat_listview,
            expand=True
        )
        self.user_input = TextField(

            hint_text='Type your instructions here ...',
            hint_style=text_style_content,
            border=InputBorder.OUTLINE,
            border_color=colors.WHITE24,
            expand=True,
            border_radius=20,
            content_padding=padding.only(left=15),
            autocorrect=True,
            enable_suggestions=True,
            multiline=True,
            max_lines=3,
            text_vertical_align=VerticalAlignment.CENTER,
            shift_enter=True,
            on_submit= lambda x: self.message_build(
                            controller=self.main_chat_listview,
                            prompt=self.user_input.value
                        )


        )

        self.chat_bar = Container(
            bgcolor=colors.TRANSPARENT,
            border_radius=10,
            content=Row(
                controls=[
                    IconButton(
                        icon=icons.MIC,
                        scale=1,
                        alignment=alignment.center,
                        icon_color=colors.WHITE
                    ),
                    self.user_input,
                    IconButton(
                        icon=icons.SEND_ROUNDED,
                        icon_color=colors.WHITE,
                        on_click=lambda x: self.message_build(
                            controller=self.main_chat_listview,
                            prompt=self.user_input.value
                        )
                    ),
                ],
                expand=True,
                spacing=0
            ),
            padding=padding.all(5),
            animate=animation.Animation(
                duration=1000, curve=AnimationCurve.FAST_OUT_SLOWIN),

        )

        self.data_view_left = Container(
            # height=2000,
            bgcolor=colors.BLACK12,
            border_radius=20,
            content=self.main_chat_listview,
            expand=True,
            shadow = shadow

        )

        self.arrange_row = Row(
            alignment=MainAxisAlignment.START,
            controls=[
                self.left_side_container,
                Column(
                    controls=[
                        self.data_view_left,
                        self.chat_bar
                    ],
                    expand=True,
                    spacing=5
                )
            ],
            expand=True
        )

        self.page_content = Container(
            # bgcolor=colors.BLACK54,
            alignment=alignment.center,
            content=self.arrange_row,
            margin=5,
            expand=True

        )

        self.content = self.page_content


# -------------------functions====------------------------------


# ------------------------

        self.analyzing = ModelLoadingContainer()


    def message_build(self,  controller, prompt: str):

        controller.controls.append(
            Row(
                controls=[
                    CircleAvatar(
                        content=Image(
                            src=r'assets\images\ashour.jpg',
                            border_radius=20,
                            scale=0.7
                        ),
                        bgcolor=colors.TRANSPARENT,
                    ),
                    Container(
                        bgcolor=colors.BLACK45,
                        border_radius=10,
                        expand=False,
                        content=Text(
                            prompt,
                            text_align=TextAlign.JUSTIFY,
                            style=text_style
                        ),
                        padding=padding.all(5),
                        shadow=shadow,
                        on_click=lambda x: self.page.set_clipboard(
                            x.content.value)
                    ),
                ],
                spacing=1,
                scroll=True,
                alignment=MainAxisAlignment.END

            )
        )
        self.chat_history.add_user_msg(self.page.client_storage.get('file_name') , self.user_input.value)

        self.user_input.value = None
        self.generate(controller=controller, prompt=prompt)
        self.page.update()
        

    def agent_respo(self, prompt):
        
        respo = self.generate(prompt=prompt)
        return respo

    # def SideBarAnimate(self, e):
    #     self.left_side_container.width = 200 if self.left_side_container.width == 40 else 40
    #     self.data_view_left.width = 625 if self.data_view_left.width == 785 else 785
    #     self.chat_bar.width = 625 if self.chat_bar.width == 785 else 785
    #     self.page.update()

    def pick_files_result(self, e: FilePickerResultEvent):

        file_path = e.files[0].path
        file_name = e.files[0].name

        self.page.client_storage.set('file_name', file_name)
        self.page.client_storage.set('file_path', file_path)

        self.analyse_file(file_path=file_path, file_name=file_name)
        print(file_path)
        self.side_bar_list.controls.append(
            RecentProjects(
                file_name=file_name,
                file_path=file_path,
                function=self.SelectExistProject)
        )
        self.side_bar_list.controls.append(Divider(thickness=0.5))

        self.side_bar_list.update()
        self.page.update()

    def analyse_file(self, file_name, file_path):
        url = r'http://localhost:8080/pdfanalyzer'
        state = requests.post(url=url, json={
            "file_name": file_name,
            "file_path": file_path
        })



    def generate(self, controller,  prompt):
        url = r'http://localhost:8080/generate'

        controller.controls.append(self.analyzing)
        controller.update()
        self.page.update()

        response = requests.post(url=url, json={
            "file_name": self.page.client_storage.get('file_name'),
            "file_path": self.page.client_storage.get('file_path'),
            "prompt": prompt
        }, stream=True)

        controller.controls.remove(self.analyzing)
        controller.update()
        self.page.update()

        controller.controls.append(ModelResponseContainer())

        for chunk in response.iter_content(124):
            if chunk:
                # Process or print the streamed data
                controller.controls[-1].controls[-1].controls[-1].content.content.controls[0].value += chunk.decode('utf-8')
                self.page.update()
                self.fullrespo.append(chunk.decode('utf-8'))
        
        self.chat_history.add_ai_msg(self.page.client_storage.get('file_name'),self.ai_respo.join(i for i in self.fullrespo))
        
        self.chat_history.StoreChat(self.page.client_storage.get('file_name'))
        self.ai_respo = ''
        self.fullrespo=[]
        
        

    def SelectExistProject(self, e):

        self.analyse_file(
            e.control.data['file_name'], e.control.data['file_path'])

        self.page.client_storage.set('file_name', e.control.data['file_name'])
        self.page.client_storage.set('file_path', e.control.data['file_path'])

        print('--' * 80)
        print(self.page.client_storage.get('file_name'))
        print(self.page.client_storage.get('file_path'))

    def signout(self, e):
    
        sign_out_url = "http://localhost:8080/sign_out"
        
        try:
            # Get the token from client storage
            token = self.page.client_storage.get('usertoken')
            
            if token:
                # Set the Authorization header with the JWT token
                headers = {
                    "Authorization": f"Bearer {token}"
                }
                
                # Make the sign-out request
                sign_out_response = requests.post(sign_out_url, headers=headers)
                
                # Clear the user token from client storage
                self.page.client_storage.remove('usertoken')
                
                # Get the message from the response
                message = sign_out_response.json().get("msg")
            else:
                message = "No active session found."
            
            # Display a snack bar message
            self.page.snack_bar = Snack(message=message)
            self.page.snack_bar.open = True
            self.page.update()

            # Redirect or update the page after sign-out if needed
            self.page.go('/')
            self.page.update()

        except Exception as ex:
            # Handle exceptions and display the error message
            self.page.snack_bar = Snack(message=str(ex))
            self.page.snack_bar.open = True
            self.page.update()
            self.page.snack_bar = None
