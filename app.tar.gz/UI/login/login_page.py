from flet import *
import requests
from UI.main_page.strings import *
from UI.controls.snack import Snack
from UI.main_page.main_ui import MainPage



# db = Blackopsml_db()


class AuthPage(Container):
    def __init__(self, page ):
        super().__init__()

        self.page = page
        self.light_color = light_color
        self.background_color = background_color
        self.foreground_color = foreground_color
        self.shadow = shadow
        self.text_style = text_style
        self.text_style_header = text_style_header
        self.text_style_content = text_style_content
        self.expand = True
        self.alignment = alignment.center

        self.logo = Image(
            src=r'assets\images\logo-L.png',
            scale=0.7,

        )


        self.first_name_input = Container(
            shadow=self.shadow,
            padding=padding.all(5),
            border_radius=25,
            content=TextField(
                width=140,
                height=40,
                border_radius=20,
                bgcolor=colors.WHITE12,
                hint_text='First Name...',
                hint_style=self.text_style,
                password=False,
                can_reveal_password=False,
                content_padding=padding.all(5),
                border_width=0,
                tooltip='Black OPS',
                cursor_color=colors.BLACK,
                cursor_width=0.3,
                text_style=self.text_style_content,
                on_change=self.EmptyChecker,
                expand=True,
                error_style=TextStyle(
                    size=9
                )

            )
        )

        self.last_name_input = Container(
            shadow=self.shadow,
            padding=padding.all(5),
            border_radius=25,
            content=TextField(
                width=140,
                height=40,
                border_radius=20,
                bgcolor=colors.WHITE12,
                hint_text='Last Name...',
                hint_style=self.text_style,
                password=False,
                can_reveal_password=False,
                content_padding=padding.all(5),
                border_width=0,
                tooltip='OPS',
                cursor_color=colors.BLACK,
                cursor_width=0.3,
                text_style=self.text_style_content,
                on_change=self.EmptyChecker,
                expand=True,
                error_style=TextStyle(
                    size=9
                )
            )
        )
        self.name_form_row = Row(
            alignment=MainAxisAlignment.CENTER,
            controls=[
                self.first_name_input,
                self.last_name_input,
            ],
            
        )

        self.email_input = Container(
            shadow=self.shadow,
            padding=padding.all(5),
            border_radius=25,
            content=TextField(
                width=300,
                height=40,
                border_radius=20,
                bgcolor=colors.WHITE12,
                hint_text='Email...',
                hint_style=self.text_style,
                password=False,
                can_reveal_password=False,
                content_padding=padding.all(5),
                border_width=0,
                tooltip='Example@domain.com',
                cursor_color=colors.BLACK,
                cursor_width=0.3,
                text_style=self.text_style_content,
                error_style=TextStyle(
                    size=8,
                    font_family=r'assets\fonts\alfont_com_SFProAR_semibold.ttf'
                ),
                on_change=self.EmptyChecker,
                expand=True,
                autofill_hints=[AutofillHint.EMAIL]
            ),

        )

        self.google_logo = Container(
            bgcolor=self.foreground_color,
            width=60,
            height=60,
            content=Row(
                alignment=alignment.center,
                controls=[
                    Lottie(
                        src=r'assets\icons\google.lottie',
                        repeat=True,
                        animate=True,
                        background_loading=True,
                        reverse=True,
                        scale=0.5
                    )
                ]

            )
        )

        self.password_input = Container(
            shadow=self.shadow,
            padding=padding.all(5),
            border_radius=25,
            content=TextField(
                width=300,
                height=40,
                border_radius=20,
                bgcolor=colors.WHITE12,
                hint_text='Password...',
                hint_style=self.text_style,
                password=True,
                can_reveal_password=True,
                content_padding=padding.all(5),
                border_width=0,
                tooltip='(8)characters min... ',
                cursor_color=colors.BLACK,
                cursor_width=0.3,
                text_style=self.text_style_content,
                error_style=TextStyle(
                    size=8,
                    font_family=r'assets\fonts\alfont_com_SFProAR_semibold.ttf'
                ),
                on_change=self.EmptyChecker,
                expand=True,
                autofill_hints=[AutofillHint.PASSWORD]
            )
        )

    # def bt_animate(self,e):
    #     e.control.width = 90 if e.control.width == 50 else 50
    #     e.control.content.controls[0].text = 'Login' if e.control.content.controls[0].text == '' else ''
    #     e.control.update()

        self.submit_bt = IconButton(
            icon=icons.ARROW_CIRCLE_RIGHT_OUTLINED,
            scale=1.4,
            icon_color=colors.WHITE70,
            on_click= self.signin
        )


        self.sign_up_bt_go = IconButton(
            icon=icons.ARROW_CIRCLE_RIGHT_OUTLINED,
            icon_color=colors.WHITE70,
            scale = 1.4 ,
            on_click= self.signup
        )

        self.forget_password_bt = TextButton(
            text='Forget Password ?',
            on_click=lambda x: print('forget password...'),
            style=ButtonStyle(
                color=colors.WHITE,
                overlay_color=colors.WHITE10
            )
        )

        self.sign_up_bt = TextButton(
            text='Sign Up',
            style=ButtonStyle(
                color=colors.WHITE,
                overlay_color=colors.WHITE10,
            ),

            on_click=self.sign_view_changer


        )

        self.forget_password = Row(
            alignment=MainAxisAlignment.CENTER,
            spacing=2,
            controls=[
                self.sign_up_bt,
                self.forget_password_bt
            ],
            
        )

        self.sign_in_controls = [
            Container(
                height=50
                ),
            self.logo,

            Column(
                controls=[
                    self.email_input,
                    self.password_input,
                    self.submit_bt,
                    self.forget_password,
                    
                ],
                horizontal_alignment=CrossAxisAlignment.CENTER
            ),
            Text(
                'With click on Start button , You agree that we collect developers Emails to improve our software ...',
                text_align=TextAlign.CENTER,
                style=TextStyle(
                    size=11,
                    color=colors.RED_200
                )
            ),

            Text(
                value='Copyright © 2024 Pocket Company . All rights reserved.',
                style=self.text_style_content
            )
        ]

        self.sign_up_controls = [
            Container(
                height=70,
            ),
            self.logo,
            Column(
                horizontal_alignment=CrossAxisAlignment.CENTER,
                controls=[
                    self.name_form_row,
                    self.email_input,
                    self.password_input,
                    self.sign_up_bt_go,
                    self.forget_password,

                ]
            ),
            Container(
                height=95
            ),
            Text(
                value='Copyright © 2024 Black Company . All rights reserved.',
                style=self.text_style_content
            )
        ]

        self.form_view = Column(
            alignment=MainAxisAlignment.SPACE_BETWEEN,
            horizontal_alignment=CrossAxisAlignment.CENTER,
            controls=self.sign_in_controls,


        )
        
        self.auth_form_content = Container(
            bgcolor=colors.BLACK54,
            shadow=self.shadow,
            padding=padding.all(5),
            border_radius=20,
            alignment=alignment.center,
            content=self.form_view,
            expand=True,
            expand_loose=True
        )

        self.content = self.auth_form_content


# -------------------functions====------------------------------

    def sign_view_changer(self ,e ):
        self.form_view.controls = self.sign_up_controls if self.form_view.controls == self.sign_in_controls else self.sign_in_controls
        self.sign_up_bt.text = 'Sign In' if self.sign_up_bt.text == 'Sign Up' else 'Sign Up'
        self.form_view.update()
        # self.auth_form_content.update()

    def EmptyChecker(self, e):
        if e:
            e.control.error_text = 'Field must be not empty' if e.control.value == '' else ''
            e.control.update()
        else:
            return
    def ValueChecker(self):

        done = False
        if not self.first_name_input.content.value == '':
            firstname = self.first_name_input.content.value

        else:
            self.first_name_input.content.error_text = 'First name must not empty'

        if not self.last_name_input.content.value == '':
            lastname = self.last_name_input.content.value

        else:
            self.last_name_input.content.error_text = 'last name must not empty'

        if not self.email_input.content.value == '':
            email = self.email_input.content.value

        else:
            self.email_input.content.error_text = 'email must not empty'

        if not self.password_input.content.value == '':
            password = self.password_input.content.value

        else:
            self.password_input.content.error_text = 'password must not empty'

    
    def signup(self,e):
        signup_url = "http://127.0.0.1:8080/signup"
        signup_data = {
            "first_name": self.first_name_input.content.value,
            "last_name": self.last_name_input.content.value,
            "email": self.email_input.content.value,
            "password": self.password_input.content.value
        }

        signup_response = requests.post(signup_url, json=signup_data)
        message = signup_response.json().get('message')
        state = signup_response.json().get('status_code')
        print(state)
        if state ==201 :
            self.page.snack_bar = Snack(message=message)
            self.page.snack_bar.open = True
            self.page.update()
            self.form_view.controls = self.sign_in_controls if self.form_view.controls == self.sign_up_controls else self.sign_up_controls
            self.sign_up_bt.text = 'Sign In' if self.sign_up_bt.text == 'Sign Up' else 'Sign Up'
            self.form_view.update()        
        
        
    def signin(self,e ):
        global message
        login_url = "http://localhost:8080/login"
        
        try:
            login_data = {
                "email": self.email_input.content.value,
                "password": self.password_input.content.value
            }
            login_response = requests.post(login_url, json=login_data)
            token = login_response.json().get("access_token")
            self.page.client_storage.set('usertoken' , token)
            message = login_response.json().get("message")
            self.page.snack_bar = Snack(message=message)
            self.page.snack_bar.open = True
            self.page.update()
            self.page.go('/mainpage')
            self.page.update()
        except:
            self.page.snack_bar = Snack(message=message)
            self.page.snack_bar.open = True
            self.page.update()
            self.page.snack_bar =None

    

        
        