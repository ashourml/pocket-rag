from database.mongo_db import Blackopsml_db



def create_user(firstname , lastname , email , password):
    
    full_name = firstname + lastname
    msg = ""
    try:
        create_user = Blackopsml_db.sign_up(
            name=full_name,
            email= email,
            password= password,
        )
        if create_user:
            msg = "Success , now you can login ..."
            return msg
    except:
        msg = "Error founded , check email or password ..."
        return msg
    
    
def login(email , password):
    
    try:
        login = Blackopsml_db.sign_in(
            email=email ,
            password=password,
        )
    except:
        print('error founded ')