import json

class Project:
    def __init__(self, name=None, data=None):
        self.name = name
        self.data = data

    def save_to_pai(self, filename):
        # Serialize project data
        project_data = {
            "data": self.data
        }
        # Write to a .pai file
        with open(filename, 'w') as file:
            json.dump(project_data, file)

    @staticmethod
    def load_from_pai(filename):
        # Read the .pai file and deserialize the data
        with open(filename, 'r') as file:
            project_data = json.load(file)

        # Create a Project instance from the loaded data
        project = Project(name=project_data['name'], data=project_data['data'])
        return project
