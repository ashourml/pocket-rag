from flask import Flask, Response, jsonify, redirect, url_for, render_template, request, make_response
from llama_index.llms.ollama import Ollama 
from llama_index.core import Settings 
from llama_index.embeddings.ollama import OllamaEmbedding
from lmparse import RAG
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_jwt_extended import JWTManager, jwt_required, get_jwt_identity, create_access_token, unset_jwt_cookies
from werkzeug.security import generate_password_hash, check_password_hash
from flask_admin import Admin
from flask_admin.contrib.sqla import ModelView
from datetime import datetime
import stripe

# App and Database setup
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///pocket-ai.db'
app.config['SECRET_KEY'] = '2314455'
app.config['JWT_SECRET_KEY'] = '0000000000'
app.config['STRIPE_SECRET_KEY'] = 'your_stripe_secret_key'
db = SQLAlchemy(app)
migrate = Migrate(app, db)
jwt = JWTManager(app)
stripe.api_key = app.config['STRIPE_SECRET_KEY']

# Llama model settings
Settings.llm = Ollama(
    model='wizardlm2:latest',
    temperature=0,
    context_window=1024,
    request_timeout=480.0
)

Settings.embed_model = OllamaEmbedding(
    model_name='nomic-embed-text:v1.5',
    embed_batch_size=10,
)

model = Ollama(model='llama3.1', temperature=1)

# User model
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String(50))
    last_name = db.Column(db.String(50))
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    verified = db.Column(db.Boolean, default=False)
    subscription_status = db.Column(db.String(50), default='free_trial')
    tokens_used = db.Column(db.Integer, default=0)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

# Conversation model
class Conversation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    conversation_key = db.Column(db.String(255), nullable=False)
    conversation_data = db.Column(db.JSON, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    user = db.relationship('User', backref=db.backref('conversations', lazy=True))

# Admin panel setup
admin = Admin(app, name='Admin Panel')
admin.add_view(ModelView(User, db.session))
admin.add_view(ModelView(Conversation, db.session))

# Routes
@app.route('/signup', methods=['POST'])
def signup():
    data = request.json
    try:
        hashed_password = generate_password_hash(data['password'], method='pbkdf2:sha256')
        new_user = User(
            first_name=data['first_name'],
            last_name=data['last_name'],
            email=data['email'],
            password_hash=hashed_password
        )
        db.session.add(new_user)
        db.session.commit()
        return jsonify({'message': 'User created successfully',
                        'status_code': 201}), 201
    except :
        return jsonify({'message' : 'username or email already exist , try again',
                       'status_code': 400}) , 400

@app.route('/login', methods=['POST'])
def login():
    data = request.json
    user = User.query.filter_by(email=data['email']).first()
    if user and user.check_password(data['password']):
        access_token = create_access_token(identity=user.id)
        return jsonify({'access_token': access_token , 
                        'message' : 'Sing in successfully ...'}), 200
    return jsonify({'message': 'Invalid credentials'}), 401

@app.route('/sign_out', methods=['POST'])
@jwt_required()
def sign_out():
    response = jsonify({"msg": "Successfully signed out"})
    unset_jwt_cookies(response)
    return response

@app.route('/ai', methods=['POST'])
@jwt_required()
def ai_response():
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    
    if user.tokens_used >= 100 and user.subscription_status == 'free_trial':
        return jsonify({'message': 'Free trial limit reached'}), 403

    json_data = request.json
    data = json_data.get('query')
    response = model.invoke(data)
    
    user.tokens_used += 1
    db.session.commit()
    
    return response, 200

@app.route('/pdfanalyzer', methods=['POST'])
@jwt_required()
def pdf_analyzer():
    json_data = request.json
    file_name = json_data.get('file_name')
    file_path = json_data.get('file_path')
    
    rag = RAG(filename=file_name, file_path=file_path)
    
    response = {'status': 'Analyse success ...'}
    
    return response, 200

@app.route('/generate', methods=['POST'])
@jwt_required()
def generate():
    json_data = request.json
    file_name = json_data.get('file_name')
    file_path = json_data.get('file_path')
    prompt = json_data.get('prompt')
    
    rag = RAG(filename=file_name, file_path=file_path)
    
    def stream():
        respo = rag.Act(prompt=prompt)
        for chunk in respo.response_gen:
            yield chunk
            
    return Response(stream(), content_type='text/plain')

@app.route('/save-conversation', methods=['POST'])
@jwt_required()
def save_conversation():
    user_id = get_jwt_identity()
    data = request.json
    
    conversation_key = data.get('conversation_key')
    conversation_data = data.get('conversation_data')
    
    # Save the conversation
    new_conversation = Conversation(
        user_id=user_id,
        conversation_key=conversation_key,
        conversation_data=conversation_data
    )
    
    db.session.add(new_conversation)
    db.session.commit()
    
    return jsonify({'message': 'Conversation saved successfully'}), 201

@app.route('/get-conversations', methods=['GET'])
@jwt_required()
def get_conversations():
    user_id = get_jwt_identity()
    
    conversations = Conversation.query.filter_by(user_id=user_id).all()
    
    conversations_list = [
        {
            'conversation_key': conv.conversation_key,
            'conversation_data': conv.conversation_data,
            'created_at': conv.created_at
        }
        for conv in conversations
    ]
    
    return jsonify(conversations_list), 200

@app.route('/create-checkout-session', methods=['POST'])
@jwt_required()
def create_checkout_session():
    try:
        checkout_session = stripe.checkout.Session.create(
            payment_method_types=['card'],
            line_items=[{
                'price_data': {
                    'currency': 'usd',
                    'product_data': {
                        'name': 'Subscription',
                    },
                    'unit_amount': 5000,  # 50.00 USD
                },
                'quantity': 1,
            }],
            mode='subscription',
            success_url=url_for('success', _external=True) + '?session_id={CHECKOUT_SESSION_ID}',
            cancel_url=url_for('cancel', _external=True),
        )
        return jsonify({'sessionId': checkout_session['id']})
    except Exception as e:
        return jsonify(error=str(e)), 403

@app.route('/success')
def success():
    return "Payment successful"

@app.route('/cancel')
def cancel():
    return "Payment canceled"

@app.route('/webhook', methods=['POST'])
def stripe_webhook():
    payload = request.get_data(as_text=True)
    sig_header = request.headers.get('Stripe-Signature')

    try:
        event = stripe.Webhook.construct_event(
            payload, sig_header, app.config['STRIPE_SECRET_KEY']
        )
    except ValueError as e:
        return jsonify(success=False), 400
    except stripe.error.SignatureVerificationError as e:
        return jsonify(success=False), 400

    if event['type'] == 'checkout.session.completed':
        session = event['data']['object']
        user_id = session['client_reference_id']
        user = User.query.get(user_id)
        user.subscription_status = 'subscribed'
        db.session.commit()

    return jsonify(success=True), 200

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(host='0.0.0.0', port=8080, debug=True)
