from llama_index.core import VectorStoreIndex, SimpleDirectoryReader, Settings, SummaryIndex, SimpleKeywordTableIndex, load_index_from_storage
from llama_index.embeddings.ollama import OllamaEmbedding
from llama_index.core import StorageContext
import os
from llama_index.core.response.notebook_utils import display_response
from llama_index.core.node_parser import SentenceSplitter
from llama_index.llms.ollama import Ollama
from llama_index.storage.docstore.mongodb import MongoDocumentStore
from llama_index.storage.index_store.mongodb import MongoIndexStore
import matplotlib.pyplot as plt

import nest_asyncio
import asyncio  # Import asyncio for running the event loop

nest_asyncio.apply()

import logging
import sys

logging.basicConfig(stream=sys.stdout, level=logging.INFO)
logging.getLogger().addHandler(logging.StreamHandler(stream=sys.stdout))

llm = Ollama(
    model='llama3.1',
    request_timeout=120.0,
    context_window=3000,
)

embedding = OllamaEmbedding(
    model_name='mxbai-embed-large:335m',
    embed_batch_size=50,
)

Settings.embed_model = embedding
Settings.llm = llm


async def StoringData():
    global storage_context
    # load some documents
    documents = SimpleDirectoryReader("./data").load_data()

    # Await the asynchronous function
    nodes = await SentenceSplitter().aget_nodes_from_documents(documents=documents)

    storage_context = StorageContext.from_defaults(
        docstore=MongoDocumentStore.from_uri(uri=r"mongodb://localhost:27017/"),
        index_store=MongoIndexStore.from_uri(uri=r"mongodb://localhost:27017/"),
    )

    storage_context.docstore.add_documents(nodes)

    summary_index = SummaryIndex(nodes, storage_context=storage_context)
    vector_index = VectorStoreIndex(nodes, storage_context=storage_context)

    keyword_table_index = SimpleKeywordTableIndex(
        nodes, storage_context=storage_context
    )

    list_id = summary_index.index_id
    vector_id = vector_index.index_id
    keyword_id = keyword_table_index.index_id

    return list_id, vector_id, keyword_id


def LoadingIndex(list_id, vector_id, keyword_id):
    global storag_context
    storag_context = StorageContext.from_defaults(
        docstore=MongoDocumentStore.from_uri(r"mongodb://localhost:27017/"),
        index_store=MongoIndexStore.from_uri(r"mongodb://localhost:27017/")
    )

    # load indices
    summary_index = load_index_from_storage(
        storage_context=storag_context, index_id=list_id
    )
    vector_index = load_index_from_storage(
        storage_context=storag_context, index_id=vector_id
    )
    keyword_table_index = load_index_from_storage(
        storage_context=storag_context, index_id=keyword_id
    )

    return summary_index, vector_index, keyword_table_index


def run(query, summary_index, vector_index, keyword_table_index):
    if 'summary' in query:
        summ = summary_index.as_query_engine()
        respo = summ.query(query)
        display_response(respo)

    if 'tell' in query:
        print(vector_index.as_query_engine().query(query))

    if 'keyword' in query:
        print(keyword_table_index.as_query_engine().query(query))


# Run the StoringData function using asyncio
async def main():
    list_id, vector_id, keyword_id = await StoringData()
    summary_index, vector_index, keyword_table_index = LoadingIndex(list_id, vector_id, keyword_id)

    while True:
        user = input('you : ')
        run(user, summary_index, vector_index, keyword_table_index)


# Execute the main function
asyncio.run(main())
