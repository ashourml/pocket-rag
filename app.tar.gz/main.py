import socket
from flet import *
import os
# from UI.main_page.main_ui import MainPage
from UI.main_page.strings import *
from UI.login.login_page import *
from UI.controls.drag_bar import DragBar
from UI.controls.converter import convert_html_to_flet


def main(page: Page):
    """create main page of our app 

    Args:
        page (Page): 
    """
    page.title = 'Blacks tube'
    page.padding = 0
    page.window.resizable = True
    page.window.title_bar_hidden = True
    page.window.title_bar_buttons_hidden = True
    page.window.frameless = True
    page.window.always_on_top = True
    page.padding = 0
    page.spacing = 0
    page.window.bgcolor = colors.TRANSPARENT
    page.bgcolor = colors.TRANSPARENT

    page.fonts = {
        'sf': r"assets\fonts\alfont_com_SFProAR_semibold.ttf",
        'sfm': r"assets\fonts\SF-Pro-Text-Medium.otf",
        'Roboto': r"assets\fonts\RobotoMono-VariableFont_wght.ttf"
    }
    page.theme = Theme(font_family='sf')
    page.auto_scroll = True


    def route_change(route):
        page.views.clear()
        page.views.append(
            View(
                "/",
                [
                    Container(
                        border_radius=0,
                        alignment=alignment.center,
                        padding=padding.all(10),
                        margin=0,
                        content=Column(
                            horizontal_alignment=CrossAxisAlignment.CENTER,
                            controls=[
                                DragBar(page = page),
                                AuthPage(page=page)

                            ]
                        ),
                        expand=True,
                        image_src=r'assets\images\background3.jpg',
                        image_opacity=50,
                        image_fit=ImageFit.FILL,


                    )
                ],
                bgcolor=colors.TRANSPARENT,
                padding=padding.all(0)
            )
        )
        if page.route == "/mainpage":
            page.views.append(
                View(
                    "/mainpage",
                    [
                        Container(
                            border_radius=0,
                            alignment=alignment.center,
                            padding=padding.all(10),
                            content=Column(
                                horizontal_alignment=CrossAxisAlignment.CENTER,
                                controls=[
                                    DragBar(page=page),
                                    MainPage(page=page)

                                ]
                            ),
                            expand=True,
                            image_src=r'assets\images\background3.jpg',
                            image_opacity=50,
                            image_fit=ImageFit.FILL

                        )
                    ],
                    bgcolor=colors.TRANSPARENT,
                    padding=padding.all(0)
                )
            )
        page.update()

    def view_pop(view):
        page.views.pop()
        top_view = page.views[-1]
        page.go(top_view.route)

    page.on_route_change = route_change
    page.on_view_pop = view_pop
    page.go(page.route)

    # page.add(
    #     Container(
    #         border_radius=0,
    #         alignment=alignment.center,
    #         padding=padding.all(10),
    #         content=Column(
    #             horizontal_alignment=CrossAxisAlignment.CENTER,
    #             controls=[
    #                 drag,
    #                 auth

    #             ]
    #         ),
    #         expand=True,
    #         image_src=r'assets\images\background3.jpg',
    #         image_opacity=50,
    #         image_fit=ImageFit.FILL

    #     )
    # )
    # page.update()


app(target=main, assets_dir='assets' )
